public class ShapesTest {

    public static void main(String[] args) {

        Cylinder c1 = new Cylinder();

        c1.setRadius(3);
        c1.setHeight(5);
        c1.render();
    }
}
